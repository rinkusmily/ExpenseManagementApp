package com.shrinkcom.expensemanagementapp.activities;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.shrinkcom.expensemanagementapp.R;

public class UpdateCarList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_car_list);
    }
}
