package com.shrinkcom.expensemanagementapp.adaptor;

public class CurrencyAdapter {
}
