package com.shrinkcom.expensemanagementapp.reInterface;

import android.view.MotionEvent;

public interface OnActivityTouchListener {
    void getTouchCoordinates(MotionEvent ev);
}