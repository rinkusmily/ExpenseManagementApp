package com.shrinkcom.expensemanagementapp.reInterface;

public interface RecyclerbuttonClick {

    public void onItemClick(int position, int type);
}
