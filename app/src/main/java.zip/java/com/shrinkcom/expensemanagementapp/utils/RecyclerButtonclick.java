package com.shrinkcom.expensemanagementapp.utils;

public interface RecyclerButtonclick {

    public void onItemClick(int position, int type);
}
