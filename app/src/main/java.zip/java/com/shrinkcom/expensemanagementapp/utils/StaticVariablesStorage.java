package com.shrinkcom.expensemanagementapp.utils;

public class StaticVariablesStorage {



    final public static String AMOUNT = "";

    final public static String DATE = "";
    final public static String MODEL = "";
    final public static String PLATE_VIN ="";
    final public static String TYPE_NAME = "";
    final public static String TYPE_IMAGE = "";
    final public static String NOTE_ = "";


     public static int TAKINGS = 0;
     public static int TOTAL = 0;
     public static int PAYMENT = 0;
     public static int EXPENCE = 0;
     public static int NO_OF_CAR = 0;

     public static String CATECORY_TYPE = "";
     public static String CATEGORY_IMAGE = "";


}
